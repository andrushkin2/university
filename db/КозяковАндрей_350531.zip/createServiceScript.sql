delete from service;

insert into service (id, name, comment) values (1, "Тренажерный зал", "Занятие в тренажерном зале");
insert into service (id, name, comment) values (2, "Фитнес", "Общеооздоровительный комплекс упражнений");
insert into service (id, name, comment) values (3, "Кроссфит", "Многофункциональная тренировка");
insert into service (id, name, comment) values (4, "Массаж", "Общий массаж");
