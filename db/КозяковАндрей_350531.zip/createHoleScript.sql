delete from hole;

insert into hole (number, comment) values (1, "Небольшой зал для фитнеса");
insert into hole (number, comment) values (2, "Малый тренажерный зал");
insert into hole (number, comment) values (3, "Бассейн");
insert into hole (number, comment) values (4, "Большой тренажерный зал");
insert into hole (number, comment) values (5, "Большой тренажерный зал");
insert into hole (number, comment) values (6, "Небольшой зал для фитнеса");
