DELETE FROM vocation;

insert into vocation (id, name) values (1, "Бухгалтер");
insert into vocation (id, name) values (2, "Директор");
insert into vocation (id, name) values (3, "Менеджер");
insert into vocation (id, name) values (4, "Тренер");
insert into vocation (id, name) values (5, "Консультант");
insert into vocation (id, name) values (6, "Уборщик");
insert into vocation (id, name) values (7, "Сторожь");
