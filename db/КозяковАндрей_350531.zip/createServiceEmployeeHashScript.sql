DELETE FROM serviceemployeehash;


insert into serviceemployeehash (serviceId, employeeId) values (1, 111115);
insert into serviceemployeehash (serviceId, employeeId) values (1, 111116);
insert into serviceemployeehash (serviceId, employeeId) values (2, 111116);
insert into serviceemployeehash (serviceId, employeeId) values (2, 111117);
insert into serviceemployeehash (serviceId, employeeId) values (3, 111117);
insert into serviceemployeehash (serviceId, employeeId) values (4, 111117);
insert into serviceemployeehash (serviceId, employeeId) values (4, 111118);
insert into serviceemployeehash (serviceId, employeeId) values (1, 111118);
insert into serviceemployeehash (serviceId, employeeId) values (4, 111119);
insert into serviceemployeehash (serviceId, employeeId) values (1, 111119);
insert into serviceemployeehash (serviceId, employeeId) values (4, 111120);
insert into serviceemployeehash (serviceId, employeeId) values (3, 111120);
insert into serviceemployeehash (serviceId, employeeId) values (2, 111120);
insert into serviceemployeehash (serviceId, employeeId) values (1, 111120);
insert into serviceemployeehash (serviceId, employeeId) values (2, 123456);
insert into serviceemployeehash (serviceId, employeeId) values (3, 123456);
insert into serviceemployeehash (serviceId, employeeId) values (4, 123456);

