/// <reference path="mysql/mysql.d.ts" />
/// <reference path="node/node.d.ts" />
