DELETE FROM client;

insert into client  (passportId, firstName, lastName) values ("123123", "Вася", "Попов");
insert into client  (passportId, firstName, lastName) values ("123456", "Никита", "Слонов");
insert into client  (passportId, firstName, lastName) values ("111111", "Толик", "Стрежников");
insert into client  (passportId, firstName, lastName) values ("111112", "Валентин", "Краснов");
insert into client  (passportId, firstName, lastName) values ("111113", "Павел", "Дуров");
insert into client  (passportId, firstName, lastName) values ("111114", "Кирил", "Хорошко");
insert into client  (passportId, firstName, lastName) values ("111115", "Татьяна", "Остраченко");
insert into client  (passportId, firstName, lastName) values ("111116", "Евегений", "Филик");
insert into client  (passportId, firstName, lastName) values ("111117", "Аким", "Трутенко");
insert into client  (passportId, firstName, lastName) values ("111118", "Игнат", "Печник");
insert into client  (passportId, firstName, lastName) values ("111119", "Илья", "Годный");
insert into client  (passportId, firstName, lastName) values ("111120", "Александра", "Усович");

