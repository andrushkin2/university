DELETE FROM employee;

insert into employee  (passportId, firstName, lastName, vocation) values ("123123", "Николай", "Котяшкин", 2);
insert into employee  (passportId, firstName, lastName, vocation) values ("123456", "Слава", "Пышкин", 3);
insert into employee  (passportId, firstName, lastName, vocation) values ("111111", "Толик", "Пряжко", 5);
insert into employee  (passportId, firstName, lastName, vocation) values ("111112", "Валентина", "Краснова", 1);
insert into employee  (passportId, firstName, lastName, vocation) values ("111113", "Иосиф", "Красносельцев", 7);
insert into employee  (passportId, firstName, lastName, vocation) values ("111114", "Елизавета", "Ходько", 6);
insert into employee  (passportId, firstName, lastName, vocation) values ("111115", "Татьяна", "Мельник", 4);
insert into employee  (passportId, firstName, lastName, vocation) values ("111116", "Евегений", "Малкин", 4);
insert into employee  (passportId, firstName, lastName, vocation) values ("111117", "Зоя", "Зошко", 4);
insert into employee  (passportId, firstName, lastName, vocation) values ("111118", "Филипп", "Огушев", 4);
insert into employee  (passportId, firstName, lastName, vocation) values ("111119", "Александр", "Сушка", 4);
insert into employee  (passportId, firstName, lastName, vocation) values ("111120", "Дмитрий", "Белый", 4);
